package com.example.demott.Utils

import android.app.Application
import android.content.Context

class App : Application()