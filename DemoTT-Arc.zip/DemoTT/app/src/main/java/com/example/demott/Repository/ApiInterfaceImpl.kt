package com.example.demott.Repository

import com.example.demott.Modal.DetailData
import com.example.demott.Modal.LoginModel
import com.example.demott.Modal.RegisterModal
import com.example.demott.Modal.UserDetails
import retrofit2.Call
import retrofit2.Response

class ApiInterfaceImpl(val apiInterface: ApiInterface) : ApiInterface {

    override suspend fun generateOtp(phone: String): Response<LoginModel?>? {
        return try {
            apiInterface.generateOtp(phone = phone)
        } catch (e: Exception) {
            null
        }
    }

    override fun registerUser(
        phone: String,
        otp: String,
        lat: String,
        long: String
    ): Call<RegisterModal> {
        TODO("Not yet implemented")
    }

    override fun logout(user_login_token: String): Call<LoginModel> {
        TODO("Not yet implemented")
    }

    override fun get_all_user(user_login_token: String): Call<UserDetails> {
        TODO("Not yet implemented")
    }

    override fun demoapi(): Call<DetailData> {
        TODO("Not yet implemented")
    }

    override fun demo() {


    }
}