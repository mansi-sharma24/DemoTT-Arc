package com.example.demott.view.activity

import android.content.Intent
import androidx.activity.viewModels
import com.example.demott.ViewModel.StartViewModel
import com.example.demott.view.activity.base.BaseActivity

class StartActivity : BaseActivity() {

    override var className: String = this.javaClass.name
    private val startViewModel: StartViewModel by viewModels()

    override fun init() {
        startViewModel.isUserLogin {
            if (it == true) {
                val mainIntent = Intent(this, HomeActivity::class.java)
                startActivity(mainIntent)
                finish()
            } else {
                val mainIntent = Intent(this, MainActivity::class.java)
                startActivity(mainIntent)
                finish()
            }
        }
    }

    override fun listeners() {

    }

    override fun observer() {

    }
}