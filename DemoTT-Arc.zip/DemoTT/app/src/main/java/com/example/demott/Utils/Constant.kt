package com.example.demott.Utils

class Constant {
    companion object {
        val SAVE_USER_INFO: String = "userDetails"
        val AUTH_TOKEN: String = "authtoken"
        val SESSION: String = "session"

    }
}