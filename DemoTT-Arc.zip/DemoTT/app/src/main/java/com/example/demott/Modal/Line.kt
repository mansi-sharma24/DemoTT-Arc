package com.example.demott.Modal

data class Line(
    val line_class: String
)