package com.example.demott.Modal

data class Data(
    val timelineInfo: List<TimelineInfo>
)