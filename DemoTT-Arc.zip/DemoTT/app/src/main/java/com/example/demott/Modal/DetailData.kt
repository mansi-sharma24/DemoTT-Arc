package com.example.demott.Modal

data class DetailData(
    val `data`: Data,
    val status: Int
)