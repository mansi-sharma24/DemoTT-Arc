package com.example.demott.view.activity.base

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.LayoutRes
import androidx.fragment.app.Fragment
import com.example.demott.Utils.CommonUtils

abstract class BaseFragment(@LayoutRes id: Int) : Fragment(id) {

    abstract var className: String

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bind(view)
        listeners()
        observer()
    }

    abstract fun bind(view: View)
    abstract fun listeners()
    abstract fun observer()

    fun log(message: String, t: Throwable? = null) {
        Log.i(className, message, t)
    }

    fun showLoading(isShow: Boolean?) {
        if (isShow == true) {
            CommonUtils.dismissDialog()
            CommonUtils.showDialog(this.requireActivity())
        } else {
            CommonUtils.dismissDialog()
        }
    }

}