package com.example.demott.Modal

data class ChatDetail(var name : String = "", var auth_token: String = "", var image : String = "", var message : String = "", var type : String = "",var timestamp  : String = "",var key : String = "")


