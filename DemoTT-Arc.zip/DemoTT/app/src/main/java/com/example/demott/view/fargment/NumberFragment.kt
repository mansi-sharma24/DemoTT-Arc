package com.example.demott.view.fargment

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.navigation.Navigation
import com.example.demott.Modal.Resource
import com.example.demott.R
import com.example.demott.Utils.CommonUtils
import com.example.demott.Utils.toast
import com.example.demott.ViewModel.DemoViewModal
import com.example.demott.databinding.FragmentViewBinding
import com.example.demott.view.activity.base.BaseFragment

class NumberFragment : BaseFragment(R.layout.fragment_view) {

    override var className: String = "NumberFragment"
    private lateinit var binding: FragmentViewBinding
    private val viewModel: DemoViewModal by activityViewModels()

    override fun bind(view: View) {
        binding = FragmentViewBinding.bind(view)
    }

    override fun listeners() {
        binding.proceedBtn.setOnClickListener {
            if (binding.phoneNumber.text.toString().isEmpty()) {
                binding.phoneNumber.error = "Enter Number "
                binding.phoneNumber.requestFocus()
            } else {
                viewModel.generateOtpLive(binding.phoneNumber.text.toString())
            }
        }
    }

    override fun observer() {
        viewModel.getOtpResponse().observe(this.viewLifecycleOwner) {
            when (it) {
                is Resource.Error -> {
                    log("${it.message}")
                    context?.toast(it.message ?: "")
                }
                is Resource.Loading -> {
                    log("${it.isShow}")
                    showLoading(it.isShow)
                }
                is Resource.Success -> {
                    log("${it.data}")
                    context?.toast(it.data?.message ?: "")

                }
                null -> {
                    context?.toast("something went wrong")
                }
            }
        }
    }


}