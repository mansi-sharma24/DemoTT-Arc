package com.example.demott.Modal

data class Details(
    val auth_token: String
)