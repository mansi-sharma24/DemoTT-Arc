package com.example.demott.ViewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.demott.Utils.AppPreferences
import com.example.demott.Utils.Constant

class StartViewModel(val app: Application) : AndroidViewModel(app) {

    private val sharePref by lazy { AppPreferences(app.baseContext) }

    fun isUserLogin(isLogin: ((Boolean?) -> Unit)) {
        isLogin.invoke(sharePref.getString(Constant.SESSION).equals("1"))
    }




}