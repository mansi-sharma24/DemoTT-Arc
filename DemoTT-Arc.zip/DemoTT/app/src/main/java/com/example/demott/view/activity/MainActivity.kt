package com.example.demott.view.activity

import android.os.Bundle
import androidx.activity.viewModels
import com.example.demott.ViewModel.DemoViewModal
import com.example.demott.databinding.ActivityMainBinding
import com.example.demott.view.activity.base.BaseActivity

class MainActivity : BaseActivity() {

    val binding: ActivityMainBinding by lazy { ActivityMainBinding.inflate(layoutInflater) }
    override var className: String = "MainActivity"

    private val viewModel: DemoViewModal by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
    }

    override fun init() {
    }

    override fun listeners() {
    }

    override fun observer() {
    }
}