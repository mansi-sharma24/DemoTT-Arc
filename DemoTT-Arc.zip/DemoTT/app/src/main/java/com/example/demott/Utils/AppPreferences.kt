package com.example.demott.Utils

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson

class AppPreferences(context: Context) {
    private val sharedPreferences: SharedPreferences by lazy { context.getSharedPreferences("demo", Context.MODE_PRIVATE) }

    fun saveString(key: String?, value: String?) {
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.apply()
    }

    fun getString(key: String?): String? {
        return sharedPreferences.getString(key, "")
    }

    fun logout() {
        sharedPreferences.edit().clear().apply()
    }

    fun saveUserDetails(key: String?, registerModelClass: Any?) {
        val gson = Gson()
        val editor = sharedPreferences.edit()
        editor.putString(key, gson.toJson(registerModelClass))
        editor.apply()
    }

    fun <T> getUserDetails(key: String?, type: Class<T>?): T {
        val gson = Gson()
        return gson.fromJson(sharedPreferences.getString(key, ""), type)
    }

    fun setSettings(key: String?, value: Boolean) {
        val editor = sharedPreferences.edit()
        editor.putBoolean(key, value)
        editor.apply()
    }

    fun getSettings(key: String?): Boolean {
        return sharedPreferences.getBoolean(key, false)
    }

    val isUserFirstTime: Boolean
        get() = sharedPreferences.getBoolean("isUserFirstTime", true)

    fun setUserLoginTime() {
        val editor = sharedPreferences.edit()
        editor.putBoolean("isUserFirstTime", false)
        editor.apply()
    }

    fun login(context: Context, connected: Boolean) {
        val editor = sharedPreferences.edit()
        editor.putBoolean("connected", connected)
        editor.apply()
    }

    fun isLogin(context: Context?): Boolean {
        return sharedPreferences.getBoolean("connected", false)
    }


}