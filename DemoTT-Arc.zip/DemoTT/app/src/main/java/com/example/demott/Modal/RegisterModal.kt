package com.example.demott.Modal

data class RegisterModal(
    val details: Details,
    val message: String,
    val status: Int
)