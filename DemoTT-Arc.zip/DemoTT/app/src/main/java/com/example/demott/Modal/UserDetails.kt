package com.example.demott.Modal

data class UserDetails(
    val details: List<Detail>,
    val message: String,
    val status: Int
)