package com.example.demott.Modal

/**
 * Sealed (enum) class to differentiate between type of response we are getting and wrap response according to them.
 * */
sealed class Resource<T>(
    val data: T? = null,
    val message: String? = null,
    val isShow: Boolean? = false
) {
    class Success<T>(data: T) : Resource<T>(data)
    class Error<T>(message: String, data: T? = null) : Resource<T>(data, message)
    class Loading<T>(isShow: Boolean?, data: T? = null) : Resource<T>(isShow = isShow, data = data)
}