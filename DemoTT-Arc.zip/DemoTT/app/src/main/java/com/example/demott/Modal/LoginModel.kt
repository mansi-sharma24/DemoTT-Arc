package com.example.demott.Modal

data class LoginModel(
    val details: Int,
    val message: String,
    val status: Int
)