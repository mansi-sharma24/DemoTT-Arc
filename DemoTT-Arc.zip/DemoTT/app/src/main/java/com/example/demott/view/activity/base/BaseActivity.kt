package com.example.demott.view.activity.base

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity() {

    abstract var className: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        init()
        listeners()
        observer()
    }

    abstract fun init()
    abstract fun listeners()
    abstract fun observer()

    fun log(message: String, t: Throwable? = null) {
        Log.i(className, message, t)
    }
}